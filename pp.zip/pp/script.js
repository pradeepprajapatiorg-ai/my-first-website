"use strict";

/* =========================================================
   PIXORA
   Frontend social-media prototype
========================================================= */


/* =========================================================
   GLOBAL STATE
========================================================= */

let users = [];
let posts = [];
let stories = [];
let conversations = [];
let notifications = [];
let products = [];
let developerApps = [];

let currentUser = null;
let activeChatUser = null;
let currentCreateType = "post";


/* =========================================================
   STORAGE
========================================================= */

function loadData() {

    users =
        JSON.parse(
            localStorage.getItem("pixora_users") || "[]"
        );

    posts =
        JSON.parse(
            localStorage.getItem("pixora_posts") || "[]"
        );

    stories =
        JSON.parse(
            localStorage.getItem("pixora_stories") || "[]"
        );

    conversations =
        JSON.parse(
            localStorage.getItem("pixora_conversations") || "[]"
        );

    notifications =
        JSON.parse(
            localStorage.getItem("pixora_notifications") || "[]"
        );

    products =
        JSON.parse(
            localStorage.getItem("pixora_products") || "[]"
        );

    developerApps =
        JSON.parse(
            localStorage.getItem("pixora_developer_apps") || "[]"
        );
}


function saveData() {

    localStorage.setItem(
        "pixora_users",
        JSON.stringify(users)
    );

    localStorage.setItem(
        "pixora_posts",
        JSON.stringify(posts)
    );

    localStorage.setItem(
        "pixora_stories",
        JSON.stringify(stories)
    );

    localStorage.setItem(
        "pixora_conversations",
        JSON.stringify(conversations)
    );

    localStorage.setItem(
        "pixora_notifications",
        JSON.stringify(notifications)
    );

    localStorage.setItem(
        "pixora_products",
        JSON.stringify(products)
    );

    localStorage.setItem(
        "pixora_developer_apps",
        JSON.stringify(developerApps)
    );
}


/* =========================================================
   HELPERS
========================================================= */

function id() {

    if (
        window.crypto &&
        crypto.randomUUID
    ) {

        return crypto.randomUUID();

    }

    return (
        Date.now() +
        Math.random()
            .toString(36)
            .substring(2)
    );
}


function escapeHTML(value) {

    return String(value || "")
        .replaceAll("&", "&amp;")
        .replaceAll("<", "&lt;")
        .replaceAll(">", "&gt;")
        .replaceAll('"', "&quot;")
        .replaceAll("'", "&#039;");
}


function fileToDataURL(file) {

    return new Promise(
        (resolve, reject) => {

            const reader =
                new FileReader();

            reader.onload =
                () =>
                    resolve(reader.result);

            reader.onerror =
                reject;

            reader.readAsDataURL(file);
        }
    );
}


function getUser(username) {

    return users.find(
        user =>
            user.username === username
    );
}


/* =========================================================
   INITIALIZATION
========================================================= */

document.addEventListener(
    "DOMContentLoaded",
    init
);


function init() {

    loadData();

    setupAuth();
    setupNavigation();
    setupCreate();
    setupProfile();
    setupMessages();
    setupSearch();
    setupSettings();
    setupProfessional();
    setupDeveloper();
    setupShopping();
    setupNotifications();
    setupLive();

    checkCurrentUser();
}


/* =========================================================
   AUTHENTICATION
========================================================= */

function setupAuth() {

    document
        .getElementById("showSignup")
        .onclick =
            showSignup;

    document
        .getElementById("showLogin")
        .onclick =
            showLogin;

    document
        .getElementById("loginBtn")
        .onclick =
            login;

    document
        .getElementById("signupBtn")
        .onclick =
            signup;

    document
        .getElementById("emailMode")
        .onclick =
            setEmailMode;

    document
        .getElementById("phoneMode")
        .onclick =
            setPhoneMode;
}


function showSignup() {

    document
        .getElementById("loginForm")
        .classList.add("hidden");

    document
        .getElementById("signupForm")
        .classList.remove("hidden");
}


function showLogin() {

    document
        .getElementById("signupForm")
        .classList.add("hidden");

    document
        .getElementById("loginForm")
        .classList.remove("hidden");
}


function setEmailMode() {

    const input =
        document.getElementById(
            "signupIdentity"
        );

    input.type = "email";

    input.placeholder =
        "Email address";

    document
        .getElementById("emailMode")
        .classList.add("active");

    document
        .getElementById("phoneMode")
        .classList.remove("active");
}


function setPhoneMode() {

    const input =
        document.getElementById(
            "signupIdentity"
        );

    input.type = "tel";

    input.placeholder =
        "Mobile number";

    document
        .getElementById("phoneMode")
        .classList.add("active");

    document
        .getElementById("emailMode")
        .classList.remove("active");
}


function signup() {

    const identity =
        document
            .getElementById("signupIdentity")
            .value
            .trim();

    const username =
        document
            .getElementById("signupUsername")
            .value
            .trim()
            .toLowerCase();

    const password =
        document
            .getElementById("signupPassword")
            .value;

    const confirm =
        document
            .getElementById("signupConfirm")
            .value;


    if (
        !identity ||
        !username ||
        !password ||
        !confirm
    ) {

        alert(
            "Please fill in all fields."
        );

        return;
    }


    if (username.length < 3) {

        alert(
            "Username must have at least 3 characters."
        );

        return;
    }


    if (password.length < 6) {

        alert(
            "Password must have at least 6 characters."
        );

        return;
    }


    if (password !== confirm) {

        alert(
            "Passwords do not match."
        );

        return;
    }


    if (
        users.some(
            user =>
                user.username === username
        )
    ) {

        alert(
            "Username already exists."
        );

        return;
    }


    if (
        users.some(
            user =>
                user.identity.toLowerCase() ===
                identity.toLowerCase()
        )
    ) {

        alert(
            "Email or mobile is already registered."
        );

        return;
    }


    const user = {

        id: id(),

        identity,

        username,

        password,

        bio:
            "Welcome to Pixora ✨",

        avatar:
            "https://i.pravatar.cc/300?u=" +
            encodeURIComponent(username),

        followers: [],

        following: [],

        saved: [],

        accountType: "personal",

        private: false,

        developer: false

    };


    users.push(user);

    currentUser = user;

    localStorage.setItem(
        "pixora_current_user",
        user.id
    );

    saveData();

    showApp();

    alert(
        "Account created successfully!"
    );
}


function login() {

    const identity =
        document
            .getElementById("loginIdentity")
            .value
            .trim()
            .toLowerCase();

    const password =
        document
            .getElementById("loginPassword")
            .value;


    const user =
        users.find(
            item =>
                item.identity.toLowerCase() ===
                    identity ||
                item.username.toLowerCase() ===
                    identity
        );


    if (!user) {

        alert(
            "Account not found."
        );

        return;
    }


    if (
        user.password !== password
    ) {

        alert(
            "Incorrect password."
        );

        return;
    }


    currentUser = user;

    localStorage.setItem(
        "pixora_current_user",
        user.id
    );

    showApp();
}


function checkCurrentUser() {

    const saved =
        localStorage.getItem(
            "pixora_current_user"
        );

    if (!saved) {

        showAuth();

        return;
    }


    currentUser =
        users.find(
            user =>
                user.id === saved
        );


    if (!currentUser) {

        localStorage.removeItem(
            "pixora_current_user"
        );

        showAuth();

        return;
    }


    showApp();
}


function showAuth() {

    document
        .getElementById("authScreen")
        .classList.remove("hidden");

    document
        .getElementById("app")
        .classList.add("hidden");
}


function showApp() {

    document
        .getElementById("authScreen")
        .classList.add("hidden");

    document
        .getElementById("app")
        .classList.remove("hidden");

    renderEverything();
}


function logout() {

    localStorage.removeItem(
        "pixora_current_user"
    );

    currentUser = null;

    location.reload();
}


/* =========================================================
   NAVIGATION
========================================================= */

function setupNavigation() {

    document.addEventListener(
        "click",
        event => {

            const button =
                event.target.closest(
                    "[data-page]"
                );

            if (!button) return;

            const page =
                button.dataset.page;

            showPage(page);
        }
    );
}


function showPage(pageId) {

    document
        .querySelectorAll(".page")
        .forEach(
            page =>
                page.classList.remove(
                    "active"
                )
        );


    const page =
        document.getElementById(pageId);

    if (!page) return;

    page.classList.add("active");


    if (pageId === "homePage")
        renderFeed();

    if (pageId === "explorePage")
        renderExplore();

    if (pageId === "reelsPage")
        renderReels();

    if (pageId === "profilePage")
        renderProfile();

    if (pageId === "messagesPage")
        renderConversations();

    if (pageId === "notificationsPage")
        renderNotifications();

    if (pageId === "professionalPage")
        renderProfessional();

    if (pageId === "shoppingPage")
        renderProducts();

    if (pageId === "developerPage")
        renderDeveloperApps();
}


/* =========================================================
   CREATE
========================================================= */

function setupCreate() {

    document
        .getElementById("createButton")
        .onclick =
            openCreateModal;

    document
        .getElementById("storyCreateBtn")
        .onclick =
            function () {

                openCreateModal();

                selectCreateType(
                    "story"
                );
            };


    document
        .querySelectorAll(
            "[data-create]"
        )
        .forEach(
            button => {

                button.onclick =
                    () =>
                        selectCreateType(
                            button.dataset.create
                        );
            }
        );


    document
        .getElementById("publish")
        .onclick =
            publishContent;


    document
        .querySelectorAll(
            "[data-close]"
        )
        .forEach(
            button => {

                button.onclick =
                    () =>
                        closeModal(
                            button.dataset.close
                        );
            }
        );
}


function openCreateModal() {

    document
        .getElementById("createModal")
        .classList.add("active");

    selectCreateType("post");
}


function selectCreateType(type) {

    currentCreateType = type;

    const file =
        document.getElementById(
            "mediaFile"
        );

    if (type === "reel") {

        file.accept = "video/*";

    } else {

        file.accept =
            "image/*,video/*";
    }
}


function closeModal(idValue) {

    const modal =
        document.getElementById(idValue);

    if (modal) {

        modal.classList.remove(
            "active"
        );
    }
}


async function publishContent() {

    const file =
        document.getElementById(
            "mediaFile"
        ).files[0];

    const audio =
        document.getElementById(
            "audioFile"
        ).files[0];

    const caption =
        document
            .getElementById("postCaption")
            .value
            .trim();


    if (!file) {

        alert(
            "Select an image or video."
        );

        return;
    }


    const mediaURL =
        await fileToDataURL(file);


    let audioURL = "";

    if (audio) {

        audioURL =
            await fileToDataURL(audio);
    }


    const content = {

        id: id(),

        userId:
            currentUser.id,

        username:
            currentUser.username,

        avatar:
            currentUser.avatar,

        type:
            currentCreateType,

        media:
            mediaURL,

        mediaType:
            file.type,

        caption,

        audio:
            audioURL,

        audioName:
            audio
                ? audio.name
                : "",

        likes: [],

        comments: [],

        shares: 0,

        savedBy: [],

        created:
            Date.now()

    };


    if (
        currentCreateType ===
        "story"
    ) {

        stories.push(content);

        saveData();

        closeModal("createModal");

        renderStories();

        alert(
            "Story created!"
        );

        return;
    }


    posts.unshift(content);

    saveData();

    closeModal("createModal");

    clearCreateForm();

    renderEverything();

    showPage(
        currentCreateType === "reel"
            ? "reelsPage"
            : "homePage"
    );
}


function clearCreateForm() {

    document
        .getElementById("mediaFile")
        .value = "";

    document
        .getElementById("audioFile")
        .value = "";

    document
        .getElementById("postCaption")
        .value = "";
}


/* =========================================================
   FEED
========================================================= */

function renderFeed() {

    const feed =
        document.getElementById("feed");

    const normalPosts =
        posts.filter(
            post =>
                post.type === "post"
        );


    if (
        normalPosts.length === 0
    ) {

        feed.innerHTML = `
            <div class="dashboard-card"
                 style="text-align:center">
                <h3>No posts yet</h3>
                <p>Create your first post.</p>
            </div>
        `;

        return;
    }


    feed.innerHTML =
        normalPosts
            .map(
                post =>
                    createPostHTML(post)
            )
            .join("");
}


function createPostHTML(post) {

    const liked =
        post.likes.includes(
            currentUser.id
        );


    const saved =
        post.savedBy.includes(
            currentUser.id
        );


    const comments =
        post.comments || [];


    return `

        <article class="post">

            <div class="post-header">

                <div class="user-info">

                    <img
                        class="avatar"
                        src="${post.avatar}"
                        alt=""
                    >

                    <span class="post-user">
                        @${escapeHTML(
                            post.username
                        )}
                    </span>

                </div>

                <button
                    class="post-more"
                    data-delete-post="${post.id}"
                >
                    •••
                </button>

            </div>


            ${
                post.mediaType.startsWith("video")
                ?

                `
                    <video
                        class="post-media"
                        src="${post.media}"
                        controls
                        playsinline
                    ></video>
                `

                :

                `
                    <img
                        class="post-media"
                        src="${post.media}"
                        alt="Post"
                    >
                `
            }


            <div class="post-actions">

                <div class="action-group">

                    <button
                        class="action ${
                            liked
                                ? "liked"
                                : ""
                        }"
                        data-like-post="${post.id}"
                    >
                        ${
                            liked
                                ? "♥"
                                : "♡"
                        }
                    </button>

                    <button
                        class="action"
                        data-focus-comment="${post.id}"
                    >
                        ♡
                    </button>

                    <button
                        class="action"
                        data-share-post="${post.id}"
                    >
                        ➤
                    </button>

                </div>


                <button
                    class="action"
                    data-save-post="${post.id}"
                >
                    ${
                        saved
                            ? "🔖"
                            : "🏷"
                    }
                </button>

            </div>


            <div class="post-body">

                <div class="like-count">
                    ${post.likes.length}
                    likes
                </div>

                <div class="caption">

                    <b>
                        @${escapeHTML(
                            post.username
                        )}
                    </b>

                    ${formatText(
                        post.caption
                    )}

                </div>


                ${
                    post.audio
                    ?
                    `
                        <div class="post-music">

                            🎵

                            <span>
                                ${escapeHTML(
                                    post.audioName
                                )}
                            </span>

                            <audio
                                controls
                                src="${post.audio}"
                            ></audio>

                        </div>
                    `
                    :
                    ""
                }


                <div class="comment-list">

                    ${comments
                        .map(
                            comment => `

                                <div class="comment">

                                    <b>
                                        @${escapeHTML(
                                            comment.username
                                        )}
                                    </b>

                                    ${escapeHTML(
                                        comment.text
                                    )}

                                </div>

                            `
                        )
                        .join("")}

                </div>

            </div>


            <div class="comment-box">

                <input
                    id="comment-${post.id}"
                    placeholder="Add a comment..."
                >

                <button
                    data-comment-post="${post.id}"
                >
                    Post
                </button>

            </div>

        </article>

    `;
}


function formatText(text) {

    return escapeHTML(text)
        .replace(
            /(#\w+)/g,
            '<span class="hashtag">$1</span>'
        )
        .replace(
            /(@\w+)/g,
            '<span class="hashtag">$1</span>'
        );
}


/* =========================================================
   LIKE / COMMENT / SHARE / SAVE
========================================================= */

document.addEventListener(
    "click",
    event => {

        const like =
            event.target.closest(
                "[data-like-post]"
            );

        if (like) {

            likePost(
                like.dataset.likePost
            );

            return;
        }


        const comment =
            event.target.closest(
                "[data-comment-post]"
            );

        if (comment) {

            addComment(
                comment.dataset.commentPost
            );

            return;
        }


        const focus =
            event.target.closest(
                "[data-focus-comment]"
            );

        if (focus) {

            const input =
                document.getElementById(
                    "comment-" +
                    focus.dataset.focusComment
                );

            if (input)
                input.focus();

            return;
        }


        const share =
            event.target.closest(
                "[data-share-post]"
            );

        if (share) {

            sharePost(
                share.dataset.sharePost
            );

            return;
        }


        const save =
            event.target.closest(
                "[data-save-post]"
            );

        if (save) {

            savePost(
                save.dataset.savePost
            );

            return;
        }


        const deleteButton =
            event.target.closest(
                "[data-delete-post]"
            );

        if (deleteButton) {

            deletePost(
                deleteButton.dataset.deletePost
            );
        }

    }
);


function likePost(postId) {

    const post =
        posts.find(
            item =>
                item.id === postId
        );

    if (!post) return;


    const index =
        post.likes.indexOf(
            currentUser.id
        );


    if (index >= 0) {

        post.likes.splice(
            index,
            1
        );

    } else {

        post.likes.push(
            currentUser.id
        );


        if (
            post.userId !==
            currentUser.id
        ) {

            createNotification(
                post.userId,
                `${currentUser.username} liked your post.`
            );
        }
    }


    saveData();

    renderFeed();
    renderProfile();
    renderExplore();
}


function addComment(postId) {

    const input =
        document.getElementById(
            "comment-" + postId
        );

    if (!input) return;


    const text =
        input.value.trim();

    if (!text) return;


    const post =
        posts.find(
            item =>
                item.id === postId
        );

    if (!post) return;


    post.comments.push({

        id: id(),

        userId:
            currentUser.id,

        username:
            currentUser.username,

        text,

        created:
            Date.now()

    });


    if (
        post.userId !==
        currentUser.id
    ) {

        createNotification(
            post.userId,
            `${currentUser.username} commented on your post.`
        );
    }


    saveData();

    renderFeed();
}


async function sharePost(postId) {

    const post =
        posts.find(
            item =>
                item.id === postId
        );

    if (!post) return;


    post.shares++;


    saveData();


    if (
        navigator.share
    ) {

        try {

            await navigator.share({

                title:
                    "Pixora post",

                text:
                    "Check out this post on Pixora."

            });

        } catch {
            // Cancelled
        }

    } else {

        alert(
            "Post shared!"
        );
    }
}


function savePost(postId) {

    const post =
        posts.find(
            item =>
                item.id === postId
        );

    if (!post) return;


    const index =
        post.savedBy.indexOf(
            currentUser.id
        );


    if (index >= 0) {

        post.savedBy.splice(
            index,
            1
        );

        currentUser.saved =
            currentUser.saved.filter(
                item =>
                    item !== postId
            );

    } else {

        post.savedBy.push(
            currentUser.id
        );

        currentUser.saved.push(
            postId
        );
    }


    updateCurrentUser();

    saveData();

    renderFeed();
}


function deletePost(postId) {

    const post =
        posts.find(
            item =>
                item.id === postId
        );

    if (!post) return;


    if (
        post.userId !==
        currentUser.id
    ) {

        alert(
            "You can only delete your own post."
        );

        return;
    }


    if (
        !confirm(
            "Delete this post?"
        )
    ) return;


    posts =
        posts.filter(
            item =>
                item.id !== postId
        );


    saveData();

    renderEverything();
}


/* =========================================================
   STORIES
========================================================= */

function renderStories() {

    const container =
        document.getElementById(
            "stories"
        );

    const activeStories =
        stories.filter(
            story =>
                Date.now() -
                    story.created <
                24 * 60 * 60 * 1000
        );


    const storyUsers =
        users.filter(
            user =>
                activeStories.some(
                    story =>
                        story.userId ===
                        user.id
                )
        );


    container.innerHTML =
        storyUsers
            .map(
                user => `

                    <div class="story">

                        <div class="story-ring">

                            <img
                                src="${user.avatar}"
                                alt=""
                            >

                        </div>

                        <span>
                            ${escapeHTML(
                                user.username
                            )}
                        </span>

                    </div>

                `
            )
            .join("");


    if (
        storyUsers.length === 0
    ) {

        container.innerHTML = `
            <div style="color:#777">
                No stories yet
            </div>
        `;
    }
}


/* =========================================================
   REELS
========================================================= */

function renderReels() {

    const container =
        document.getElementById(
            "reels"
        );


    const reels =
        posts.filter(
            post =>
                post.type === "reel"
        );


    if (!reels.length) {

        container.innerHTML = `
            <div
                style="
                min-height:80vh;
                background:#000;
                color:#fff;
                display:flex;
                align-items:center;
                justify-content:center;
                text-align:center;
                "
            >
                <div>
                    <h2>No reels yet</h2>
                    <p>Create your first reel.</p>
                </div>
            </div>
        `;

        return;
    }


    container.innerHTML =
        reels
            .map(
                reel => `

                    <div class="reel">

                        <video
                            src="${reel.media}"
                            controls
                            loop
                            playsinline
                        ></video>


                        <div class="reel-info">

                            <h3>
                                @${escapeHTML(
                                    reel.username
                                )}
                            </h3>

                            <p>
                                ${formatText(
                                    reel.caption
                                )}
                            </p>

                            ${
                                reel.audio
                                ?
                                `
                                    <p>
                                        🎵
                                        ${escapeHTML(
                                            reel.audioName
                                        )}
                                    </p>
                                `
                                :
                                ""
                            }

                        </div>


                        <div class="reel-actions">

                            <button
                                data-like-reel="${reel.id}"
                            >
                                ${
                                    reel.likes.includes(
                                        currentUser.id
                                    )
                                    ? "♥"
                                    : "♡"
                                }
                            </button>

                            <span>
                                ${reel.likes.length}
                            </span>

                            <button
                                data-share-post="${reel.id}"
                            >
                                ➤
                            </button>

                        </div>

                    </div>

                `
            )
            .join("");
}


document.addEventListener(
    "click",
    event => {

        const button =
            event.target.closest(
                "[data-like-reel]"
            );

        if (!button) return;


        likePost(
            button.dataset.likeReel
        );
    }
);


/* =========================================================
   PROFILE
========================================================= */

function setupProfile() {

    document
        .getElementById("editProfile")
        .onclick =
            openEditProfile;

    document
        .getElementById("saveProfile")
        .onclick =
            saveProfile;


    document
        .querySelectorAll(
            "[data-profile-tab]"
        )
        .forEach(
            button => {

                button.onclick =
                    () =>
                        renderProfileTab(
                            button.dataset.profileTab
                        );
            }
        );
}


function renderProfile() {

    if (!currentUser) return;


    document
        .getElementById("myAvatar")
        .src =
            currentUser.avatar;


    document
        .getElementById("myUsername")
        .textContent =
            "@" +
            currentUser.username;


    document
        .getElementById("myBio")
        .textContent =
            currentUser.bio;


    const mine =
        posts.filter(
            post =>
                post.userId ===
                currentUser.id
        );


    document
        .getElementById("myPostCount")
        .textContent =
            mine.length;


    document
        .getElementById("myFollowers")
        .textContent =
            currentUser.followers.length;


    document
        .getElementById("myFollowing")
        .textContent =
            currentUser.following.length;


    renderProfileTab(
        "posts"
    );
}


function renderProfileTab(tab) {

    const grid =
        document.getElementById(
            "profileGrid"
        );


    let items = [];


    if (tab === "posts") {

        items =
            posts.filter(
                post =>
                    post.userId ===
                    currentUser.id &&
                    post.type === "post"
            );

    } else if (tab === "reels") {

        items =
            posts.filter(
                post =>
                    post.userId ===
                    currentUser.id &&
                    post.type === "reel"
            );

    } else if (tab === "saved") {

        items =
            posts.filter(
                post =>
                    post.savedBy.includes(
                        currentUser.id
                    )
            );

    } else {

        items = [];
    }


    grid.innerHTML =
        items
            .map(
                item => `

                    <div class="grid-item">

                        ${
                            item.mediaType.startsWith(
                                "video"
                            )

                            ?

                            `
                                <video
                                    src="${item.media}"
                                    muted
                                ></video>
                            `

                            :

                            `
                                <img
                                    src="${item.media}"
                                    alt=""
                                >
                            `
                        }

                    </div>

                `
            )
            .join("");
}


function openEditProfile() {

    document
        .getElementById("editUsername")
        .value =
            currentUser.username;


    document
        .getElementById("editBio")
        .value =
            currentUser.bio;


    document
        .getElementById("editModal")
        .classList.add("active");
}


async function saveProfile() {

    const username =
        document
            .getElementById("editUsername")
            .value
            .trim()
            .toLowerCase();


    const bio =
        document
            .getElementById("editBio")
            .value
            .trim();


    const avatarFile =
        document
            .getElementById("editAvatar")
            .files[0];


    if (!username) {

        alert(
            "Username is required."
        );

        return;
    }


    const duplicate =
        users.some(
            user =>
                user.id !== currentUser.id &&
                user.username === username
        );


    if (duplicate) {

        alert(
            "Username is already taken."
        );

        return;
    }


    currentUser.username =
        username;

    currentUser.bio =
        bio;


    if (avatarFile) {

        currentUser.avatar =
            await fileToDataURL(
                avatarFile
            );
    }


    updateCurrentUser();

    saveData();

    closeModal("editModal");

    renderEverything();
}


function updateCurrentUser() {

    const index =
        users.findIndex(
            user =>
                user.id ===
                currentUser.id
        );


    if (index >= 0) {

        users[index] =
            currentUser;
    }
}


/* =========================================================
   FOLLOW SYSTEM
========================================================= */

function followUser(userId) {

    const target =
        users.find(
            user =>
                user.id === userId
        );


    if (!target) return;


    if (
        !currentUser.following.includes(
            userId
        )
    ) {

        currentUser.following.push(
            userId
        );


        target.followers.push(
            currentUser.id
        );


        createNotification(
            userId,
            `${currentUser.username} started following you.`
        );


        updateCurrentUser();

        saveData();
    }
}


function unfollowUser(userId) {

    const target =
        users.find(
            user =>
                user.id === userId
        );


    if (!target) return;


    currentUser.following =
        currentUser.following.filter(
            idValue =>
                idValue !== userId
        );


    target.followers =
        target.followers.filter(
            idValue =>
                idValue !== currentUser.id
        );


    updateCurrentUser();

    saveData();
}


/* =========================================================
   SEARCH
========================================================= */

function setupSearch() {

    document
        .getElementById("searchInput")
        .oninput =
            search;
}


function search() {

    const query =
        document
            .getElementById("searchInput")
            .value
            .toLowerCase()
            .trim();


    const results =
        document.getElementById(
            "searchResults"
        );


    if (!query) {

        results.innerHTML = "";

        return;
    }


    const foundUsers =
        users.filter(
            user =>
                user.username
                    .toLowerCase()
                    .includes(query)
        );


    const foundPosts =
        posts.filter(
            post =>
                post.caption
                    .toLowerCase()
                    .includes(query)
        );


    results.innerHTML = `

        <h3 style="margin:20px 0 10px">
            People
        </h3>

        ${
            foundUsers
                .map(
                    user => `

                        <div class="search-user">

                            <img
                                src="${user.avatar}"
                                alt=""
                            >

                            <div>
                                <strong>
                                    @${escapeHTML(
                                        user.username
                                    )}
                                </strong>

                                <small>
                                    ${escapeHTML(
                                        user.bio
                                    )}
                                </small>
                            </div>

                            ${
                                user.id !==
                                currentUser.id
                                ?

                                `
                                    <button
                                        data-follow-user="${user.id}"
                                    >
                                        ${
                                            currentUser.following.includes(
                                                user.id
                                            )
                                            ? "Following"
                                            : "Follow"
                                        }
                                    </button>
                                `

                                :
                                ""
                            }

                        </div>

                    `
                )
                .join("")
        }


        <h3 style="margin:20px 0 10px">
            Posts
        </h3>

        <div class="explore-grid">

            ${
                foundPosts
                    .map(
                        post => `

                            <div class="explore-item">

                                ${
                                    post.mediaType.startsWith(
                                        "video"
                                    )

                                    ?

                                    `
                                        <video
                                            src="${post.media}"
                                            muted
                                        ></video>
                                    `

                                    :

                                    `
                                        <img
                                            src="${post.media}"
                                        >
                                    `
                                }

                            </div>

                        `
                    )
                    .join("")
            }

        </div>

    `;
}


document.addEventListener(
    "click",
    event => {

        const follow =
            event.target.closest(
                "[data-follow-user]"
            );

        if (!follow) return;


        const userId =
            follow.dataset.followUser;


        if (
            currentUser.following.includes(
                userId
            )
        ) {

            unfollowUser(userId);

        } else {

            followUser(userId);
        }


        search();
    }
);


/* =========================================================
   EXPLORE
========================================================= */

function renderExplore() {

    const grid =
        document.getElementById(
            "exploreGrid"
        );


    const shuffled =
        [...posts]
            .sort(
                () =>
                    Math.random() -
                    .5
            );


    grid.innerHTML =
        shuffled
            .map(
                post => `

                    <div class="explore-item">

                        ${
                            post.mediaType.startsWith(
                                "video"
                            )

                            ?

                            `
                                <video
                                    src="${post.media}"
                                    muted
                                ></video>
                            `

                            :

                            `
                                <img
                                    src="${post.media}"
                                >
                            `
                        }

                        <div class="explore-overlay">

                            ♥
                            ${post.likes.length}

                        </div>

                    </div>

                `
            )
            .join("");
}


function setupExplore() {

    const refresh =
        document.getElementById(
            "refreshExplore"
        );

    if (refresh)
        refresh.onclick =
            renderExplore;
}


/* =========================================================
   MESSAGING
========================================================= */

function setupMessages() {

    document
        .getElementById("sendMessage")
        .onclick =
            sendMessage;


    document
        .getElementById("backChats")
        .onclick =
            closeChat;


    document
        .getElementById("messageInput")
        .addEventListener(
            "keydown",
            event => {

                if (
                    event.key === "Enter"
                ) {

                    sendMessage();
                }
            }
        );
}


function renderConversations() {

    const container =
        document.getElementById(
            "conversationList"
        );


    const otherUsers =
        users.filter(
            user =>
                user.id !==
                currentUser.id
        );


    container.innerHTML =
        otherUsers
            .map(
                user => `

                    <div
                        class="conversation"
                        data-open-chat="${user.id}"
                    >

                        <img
                            src="${user.avatar}"
                            alt=""
                        >

                        <div class="conversation-info">

                            <strong>
                                @${escapeHTML(
                                    user.username
                                )}
                            </strong>

                            <small>
                                Tap to message
                            </small>

                        </div>

                    </div>

                `
            )
            .join("");
}


document.addEventListener(
    "click",
    event => {

        const chat =
            event.target.closest(
                "[data-open-chat]"
            );

        if (!chat) return;


        openChat(
            chat.dataset.openChat
        );
    }
);


function openChat(userId) {

    activeChatUser =
        users.find(
            user =>
                user.id === userId
        );


    if (!activeChatUser) return;


    document
        .getElementById("conversationList")
        .classList.add("hidden");


    document
        .getElementById("chat")
        .classList.remove("hidden");


    document
        .getElementById("chatName")
        .textContent =
            "@" +
            activeChatUser.username;


    renderMessages();
}


function closeChat() {

    activeChatUser = null;

    document
        .getElementById("chat")
        .classList.add("hidden");

    document
        .getElementById("conversationList")
        .classList.remove("hidden");
}


function getConversation() {

    return conversations.find(
        conversation =>
            conversation.users.includes(
                currentUser.id
            ) &&
            conversation.users.includes(
                activeChatUser.id
            )
    );
}


function sendMessage() {

    if (!activeChatUser) return;


    const input =
        document.getElementById(
            "messageInput"
        );


    const text =
        input.value.trim();


    if (!text) return;


    let conversation =
        getConversation();


    if (!conversation) {

        conversation = {

            id: id(),

            users: [
                currentUser.id,
                activeChatUser.id
            ],

            messages: []

        };


        conversations.push(
            conversation
        );
    }


    conversation.messages.push({

        id: id(),

        sender:
            currentUser.id,

        text,

        created:
            Date.now(),

        seen: false

    });


    createNotification(
        activeChatUser.id,
        `${currentUser.username} sent you a message.`
    );


    input.value = "";

    saveData();

    renderMessages();
}


function renderMessages() {

    const list =
        document.getElementById(
            "messageList"
        );


    const conversation =
        getConversation();


    if (!conversation) {

        list.innerHTML = `
            <div
                style="
                margin:auto;
                color:#777;
                "
            >
                Start a conversation
            </div>
        `;

        return;
    }


    list.innerHTML =
        conversation.messages
            .map(
                message => `

                    <div
                        class="message ${
                            message.sender ===
                            currentUser.id
                                ? "mine"
                                : ""
                        }"
                    >
                        ${escapeHTML(
                            message.text
                        )}
                    </div>

                `
            )
            .join("");


    list.scrollTop =
        list.scrollHeight;
}


/* =========================================================
   NOTIFICATIONS
========================================================= */

function setupNotifications() {

    document
        .getElementById("clearNotifications")
        .onclick =
            clearNotifications;
}


function createNotification(
    userId,
    text
) {

    notifications.unshift({

        id: id(),

        userId,

        text,

        created:
            Date.now(),

        read: false

    });


    saveData();
}


function renderNotifications() {

    const container =
        document.getElementById(
            "notifications"
        );


    const mine =
        notifications.filter(
            item =>
                item.userId ===
                currentUser.id
        );


    if (!mine.length) {

        container.innerHTML = `
            <div
                style="
                text-align:center;
                color:#777;
                padding:50px;
                "
            >
                No notifications
            </div>
        `;

        return;
    }


    container.innerHTML =
        mine
            .map(
                notification => `

                    <div class="notification">

                        <div class="notification-text">

                            ${escapeHTML(
                                notification.text
                            )}

                        </div>

                    </div>

                `
            )
            .join("");


    mine.forEach(
        notification =>
            notification.read = true
    );


    saveData();
}


function clearNotifications() {

    notifications =
        notifications.filter(
            item =>
                item.userId !==
                currentUser.id
        );


    saveData();

    renderNotifications();
}


/* =========================================================
   PROFESSIONAL / CREATOR / BUSINESS
========================================================= */

function setupProfessional() {

    document
        .getElementById("professionalBtn")
        .onclick =
            () =>
                showPage(
                    "professionalPage"
                );


    document
        .querySelectorAll(
            "[data-account-type]"
        )
        .forEach(
            button => {

                button.onclick =
                    () =>
                        switchAccountType(
                            button.dataset.accountType
                        );
            }
        );
}


function switchAccountType(type) {

    currentUser.accountType =
        type;


    updateCurrentUser();

    saveData();

    renderProfessional();

    alert(
        "Account switched to " +
        type +
        "."
    );
}


function renderProfessional() {

    document
        .getElementById("accountType")
        .textContent =
            capitalize(
                currentUser.accountType
            );


    const mine =
        posts.filter(
            post =>
                post.userId ===
                currentUser.id
        );


    const likes =
        mine.reduce(
            (total, post) =>
                total +
                post.likes.length,
            0
        );


    document
        .getElementById("analyticsPosts")
        .textContent =
            mine.length;


    document
        .getElementById("analyticsLikes")
        .textContent =
            likes;


    document
        .getElementById("analyticsFollowers")
        .textContent =
            currentUser.followers.length;


    document
        .getElementById("analyticsReach")
        .textContent =
            likes +
            currentUser.followers.length * 10;
}


/* =========================================================
   PRIVACY / SECURITY / SETTINGS
========================================================= */

function setupSettings() {

    document
        .getElementById("logoutSettings")
        .onclick =
            logout;


    document
        .querySelectorAll(
            "[data-setting]"
        )
        .forEach(
            button => {

                button.onclick =
                    () =>
                        openSettings(
                            button.dataset.setting
                        );
            }
        );
}


function openSettings(type) {

    const modal =
        document.getElementById(
            "settingsModal"
        );

    const title =
        document.getElementById(
            "settingsTitle"
        );

    const content =
        document.getElementById(
            "settingsContent"
        );


    modal.classList.add("active");


    if (type === "privacy") {

        title.textContent =
            "Privacy";


        content.innerHTML = `

            <button
                class="primary-btn"
                id="togglePrivate"
            >
                ${
                    currentUser.private
                        ? "Make account public"
                        : "Make account private"
                }
            </button>

            <button
                class="secondary-btn"
                id="blockInfo"
                style="width:100%;margin-top:10px"
            >
                Blocked accounts
            </button>

        `;


        document
            .getElementById("togglePrivate")
            .onclick =
                togglePrivateAccount;


    } else if (type === "security") {

        title.textContent =
            "Security";


        content.innerHTML = `

            <p>
                Security settings
            </p>

            <button
                class="primary-btn"
                id="changePasswordBtn"
            >
                Change password
            </button>

            <button
                class="primary-btn"
                style="margin-top:10px"
                id="twoFactorBtn"
            >
                Enable two-factor authentication
            </button>

        `;


        document
            .getElementById(
                "changePasswordBtn"
            )
            .onclick =
                changePassword;


        document
            .getElementById("twoFactorBtn")
            .onclick =
                enableTwoFactor;


    } else if (type === "account") {

        title.textContent =
            "Account";


        content.innerHTML = `

            <p>
                Username:
                <b>
                    @${escapeHTML(
                        currentUser.username
                    )}
                </b>
            </p>

            <p style="margin-top:10px">
                Account type:
                <b>
                    ${capitalize(
                        currentUser.accountType
                    )}
                </b>
            </p>

        `;


    } else if (
        type === "professional"
    ) {

        closeModal("settingsModal");

        showPage(
            "professionalPage"
        );


    } else if (
        type === "shopping"
    ) {

        closeModal("settingsModal");

        showPage(
            "shoppingPage"
        );


    } else if (
        type === "developer"
    ) {

        closeModal("settingsModal");

        showPage(
            "developerPage"
        );
    }
}


function togglePrivateAccount() {

    currentUser.private =
        !currentUser.private;

    updateCurrentUser();

    saveData();

    closeModal("settingsModal");

    alert(
        currentUser.private
            ? "Account is now private."
            : "Account is now public."
    );
}


function changePassword() {

    const newPassword =
        prompt(
            "Enter a new password:"
        );


    if (!newPassword) return;


    if (
        newPassword.length < 6
    ) {

        alert(
            "Password must have at least 6 characters."
        );

        return;
    }


    currentUser.password =
        newPassword;

    updateCurrentUser();

    saveData();

    alert(
        "Password changed."
    );
}


function enableTwoFactor() {

    alert(
        "Two-factor authentication setup interface created. Real OTP verification requires a backend/authentication provider."
    );
}


/* =========================================================
   SHOPPING
========================================================= */

function setupShopping() {

    document
        .getElementById("addProduct")
        .onclick =
            addProduct;
}


function addProduct() {

    const name =
        prompt(
            "Product name:"
        );

    if (!name) return;


    const price =
        prompt(
            "Price:"
        );


    const image =
        "https://picsum.photos/500?random=" +
        Math.floor(
            Math.random() * 1000
        );


    products.push({

        id: id(),

        owner:
            currentUser.id,

        name,

        price:
            price || "0",

        image

    });


    saveData();

    renderProducts();
}


function renderProducts() {

    const container =
        document.getElementById(
            "products"
        );


    container.innerHTML =
        products
            .map(
                product => `

                    <div class="product">

                        <img
                            src="${product.image}"
                            alt=""
                        >

                        <div class="product-body">

                            <strong>
                                ${escapeHTML(
                                    product.name
                                )}
                            </strong>

                            <div class="product-price">
                                ₹${escapeHTML(
                                    product.price
                                )}
                            </div>

                            <button
                                data-buy-product="${product.id}"
                            >
                                View product
                            </button>

                        </div>

                    </div>

                `
            )
            .join("");


    if (!products.length) {

        container.innerHTML = `
            <div
                class="dashboard-card"
                style="grid-column:1/-1;text-align:center"
            >
                <h3>No products</h3>
                <p>
                    Add a product to your shop.
                </p>
            </div>
        `;
    }
}


document.addEventListener(
    "click",
    event => {

        const button =
            event.target.closest(
                "[data-buy-product]"
            );

        if (!button) return;


        const product =
            products.find(
                item =>
                    item.id ===
                    button.dataset.buyProduct
            );


        if (product) {

            alert(
                product.name +
                "\nPrice: ₹" +
                product.price
            );
        }
    }
);


/* =========================================================
   DEVELOPER ACCOUNT
========================================================= */

function setupDeveloper() {

    document
        .getElementById(
            "createDeveloperApp"
        )
        .onclick =
            createDeveloperApp;
}


function createDeveloperApp() {

    const name =
        prompt(
            "Developer app name:"
        );


    if (!name) return;


    const app = {

        id: id(),

        owner:
            currentUser.id,

        name,

        apiKey:
            "px_" +
            Math.random()
                .toString(36)
                .substring(2) +
            Math.random()
                .toString(36)
                .substring(2),

        created:
            Date.now()

    };


    developerApps.push(
        app
    );


    currentUser.developer =
        true;


    updateCurrentUser();

    saveData();

    renderDeveloperApps();

    alert(
        "Developer app created."
    );
}


function renderDeveloperApps() {

    const container =
        document.getElementById(
            "developerApps"
        );


    const mine =
        developerApps.filter(
            app =>
                app.owner ===
                currentUser.id
        );


    container.innerHTML =
        mine
            .map(
                app => `

                    <div class="developer-app">

                        <strong>
                            ${escapeHTML(
                                app.name
                            )}
                        </strong>

                        <p>
                            App ID:
                            ${app.id}
                        </p>

                        <div class="api-key">
                            ${app.apiKey}
                        </div>

                    </div>

                `
            )
            .join("");


    if (!mine.length) {

        container.innerHTML = `
            <div
                style="
                text-align:center;
                padding:30px;
                color:#777
                "
            >
                No developer apps yet.
            </div>
        `;
    }
}


/* =========================================================
   LIVE
========================================================= */

function setupLive() {

    document
        .getElementById("sendLiveComment")
        .onclick =
            sendLiveComment;


    document
        .getElementById("endLive")
        .onclick =
            endLive;
}


function startLive() {

    showPage(
        "livePage"
    );

    document
        .getElementById("viewerCount")
        .textContent =
            "1 viewer";
}


function sendLiveComment() {

    const input =
        document.getElementById(
            "liveComment"
        );


    const text =
        input.value.trim();


    if (!text) return;


    alert(
        "Live comment sent: " +
        text
    );


    input.value = "";
}


function endLive() {

    showPage(
        "homePage"
    );

    alert(
        "Live ended."
    );
}


/* =========================================================
   GENERAL CLICK HANDLERS
========================================================= */

document.addEventListener(
    "click",
    event => {

        const create =
            event.target.closest(
                "[data-create]"
            );


        if (
            create &&
            create.dataset.create ===
                "live"
        ) {

            closeModal(
                "createModal"
            );

            startLive();
        }

    }
);


/* =========================================================
   CAPITALIZE
========================================================= */

function capitalize(value) {

    return String(value)
        .charAt(0)
        .toUpperCase() +
        String(value)
            .slice(1);
}


/* =========================================================
   RENDER EVERYTHING
========================================================= */

function renderEverything() {

    renderStories();

    renderFeed();

    renderProfile();

    renderReels();

    renderExplore();

    renderConversations();

    renderNotifications();

    renderProfessional();

    renderProducts();

    renderDeveloperApps();
}
